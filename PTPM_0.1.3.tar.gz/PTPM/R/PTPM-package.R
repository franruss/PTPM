#' PTPM: Paired Transcriptomic Perturbation Modeling
#'
#' Protocol for estimating how well baseline transcriptomic profiles predict
#' a paired perturbation phenotype without optimism from feature-selection
#' leakage or mathematical coupling. Six functions apply the same protocol to
#' different predictor or outcome models: [run_ptpm()], [run_ptpm_egfr()],
#' [run_ptpm_pathways()], [run_ptpm_weighted_score()], [run_ptpm_hybrid()] and
#' [run_ptpm_hybrid_interactions()].
#'
#' @keywords internal
"_PACKAGE"

# Loop and iterator variables used inside foreach() expressions
utils::globalVariables(c("i", "t"))
