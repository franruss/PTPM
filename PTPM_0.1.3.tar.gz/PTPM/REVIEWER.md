# Reviewer guide

This guide reproduces the PTPM analyses reported in the manuscript with the
installed `PTPM` package. Six functions apply the same protocol to different
predictor or outcome models:

| Function | Predictors | Outcome | Feature selection (K) | Default α grid |
|---|---|---|---|---|
| `run_ptpm()` | genome-wide baseline expression | mean pathway suppression S | top-K genes: 3000, 300 | 0–0.1 |
| `run_ptpm_egfr()` | a priori EGFR-axis genes (union of the Hallmark KRAS_SIGNALING_UP, MTORC1_SIGNALING and E2F_TARGETS gene sets; 569 genes) | mean pathway suppression S | top-K genes: 50, 100, 200, 300, 400, 500, all | 0–0.1 |
| `run_ptpm_pathways()` | baseline GSVA scores of the 47 non-outcome Hallmark pathways | mean pathway suppression S | top-K pathways: 10, 20, 30, 40, all | 0–1 |
| `run_ptpm_weighted_score()` | EGFR-axis genes (as `run_ptpm_egfr()`) | PC1-weighted pathway suppression, with the PCA fitted within training folds | top-K genes: 50, 100, 200, 300, 400, 500, all | 0–0.4 |
| `run_ptpm_hybrid()` | 47 non-outcome pathways (always included) + top-K EGFR-axis genes | mean pathway suppression S | top-K genes: 100, 200, 300, 400, all | 0–0.2 |
| `run_ptpm_hybrid_interactions()` | 3 non-outcome pathways (G2M_CHECKPOINT, GLYCOLYSIS, MYC_TARGETS_V1) and their pairwise interactions (always included) + top-K EGFR-axis genes | mean pathway suppression S | top-K genes: 100, 200, 300, 400, all | 0–0.2 |

All six functions share the same protocol:
- **Phenotype:** pathway suppression S = baseline (NT) minus cetuximab (CET) pathway activity, from GSVA scores of the three outcome Hallmark sets.
- **Cross-validation:** nested and patient-grouped, with 3 outer folds × 20 repeats. The inner 5-fold tuning CV is also grouped by patient.
- **2 × 2 design:**
  - feature selection on the full dataset (standard, coupling-adjusted) or within training folds (fold-internal, fully controlled);
  - with or without coupling adjustment.
- **Coupling adjustment:** the outcome is regressed on the baseline pathway score, and the regression is re-estimated within every outer and inner training fold.
- **Metric:** R² = mean over the 20 repeats of 1 − SSE/SST on each repeat's out-of-fold predictions.
- **Uncertainty:** patient-level bootstrap 95% confidence intervals, plus corrected resampled t intervals (Nadeau & Bengio) as a sensitivity analysis.
- **Diagnostics and sensitivity analyses:**
  - coupling null and partial correlations;
  - training-reference GSVA;
  - unnormalised ssGSEA;
  - pathway-specific adjustment;
  - KRAS-free phenotype;
  - exclusion of KRAS genes or of high-overlap predictor pathways.

For K equal to the whole predictor pool, no feature selection is performed. The
standard and fold-internal regimes (and the coupling-adjusted and fully
controlled regimes) therefore coincide by construction. Residual differences of
about 0.001 reflect the numerical tolerance of the solver.

## 1. Install

From the directory containing `PTPM_0.1.3.tar.gz`:

```r
install.packages("PTPM_0.1.3.tar.gz", repos = NULL, type = "source")
```

Required packages: `glmnet`, `caret`, `GSVA`, `msigdbr`, `foreach`, `doParallel`.
`msigdbr` is also used to retrieve all 50 Hallmark gene sets for
`run_ptpm_pathways()`, `run_ptpm_hybrid()` and `run_ptpm_hybrid_interactions()`.
`Rcpp` is optional: it compiles a fast kernel for the training-reference GSVA
sensitivity analysis, and a slower pure-R version is used without it.

## 2. Load

```r
library(PTPM)
example_data <- load_ptpm_example()
```

No `source()` call is required: the functions in the installed package are
loaded automatically by R.

## 3. Quick smoke test (a few minutes per model)

Every function accepts the same arguments. The settings below switch off the
heavier analyses and use only two repeats:

```r
smoke_args <- list(
  expression = example_data$expression,
  metadata = example_data$metadata,
  repeats = 2,
  n_boot = 200,
  gsva_sensitivity = FALSE,
  ssgsea_sensitivity = FALSE,
  robustness = FALSE,
  n_perm_coupling = 100,
  seed = 123,
  n_cores = parallel::detectCores() - 1
)
smoke <- do.call(run_ptpm_egfr, smoke_args)
smoke$results_genome_wide
```

## 4. Full analysis (manuscript settings)

The manuscript settings are `k = 3`, `repeats = 20`, `n_boot = 2000` and
`seed = 123`, with each function's default K grid. For `run_ptpm()` the K values
are `top_k_values = c(3000, 300)`.

```r
common_args <- list(
  expression = example_data$expression,
  metadata = example_data$metadata,
  k = 3,
  repeats = 20,
  n_boot = 2000,
  seed = 123,
  n_cores = parallel::detectCores() - 1
)

models <- list(
  genome_wide        = list(fun = run_ptpm, extra = list(top_k_values = c(3000, 300))),
  egfr_axis          = list(fun = run_ptpm_egfr),
  pathways           = list(fun = run_ptpm_pathways),
  weighted_score     = list(fun = run_ptpm_weighted_score),
  hybrid             = list(fun = run_ptpm_hybrid),
  hybrid_interaction = list(fun = run_ptpm_hybrid_interactions)
)

results <- list()
for (nm in names(models)) {
  cat("\n#####", nm, "#####\n")
  t0 <- Sys.time()
  results[[nm]] <- do.call(models[[nm]]$fun, c(common_args, models[[nm]]$extra))
  print(Sys.time() - t0)
  saveRDS(results[[nm]], paste0("ptpm_", nm, ".rds"))
}
```

Each model can also be run on its own, for example:

```r
result <- run_ptpm_hybrid(
  expression = example_data$expression,
  metadata = example_data$metadata,
  k = 3, repeats = 20, n_boot = 2000, seed = 123,
  n_cores = parallel::detectCores() - 1
)
```

## 5. Inspect the principal results

The output has the same structure for all six models. The table
`results_genome_wide` keeps this name for every model.

```r
result <- results$egfr_axis       # any of the six models

result$results_genome_wide        # R² of the four regimes for each K
result$confidence_intervals       # R² with patient-bootstrap 95% CI
result$contrast_intervals         # paired differences between regimes, with 95% CI
result$leakage_audit              # where each data-dependent step is estimated
result$definitions                # definitions of "fully controlled" and of R²
```

A compact comparison of the fully controlled R² across models:

```r
do.call(rbind, lapply(names(results), function(nm) {
  ci <- results[[nm]]$confidence_intervals
  ci <- ci[ci$regime == "fully_controlled", c("K", "R2", "boot_lower", "boot_upper")]
  cbind(model = nm, ci)
}))
```

## 6. Diagnostics and sensitivity analyses

```r
result$coupling_null            # cor(b, S) vs permutation of the NT/CET pairing
result$gsva_ref_validation      # check that the reference GSVA reproduces GSVA::gsva()
result$gsva_sensitivity         # cohort-level vs training-reference GSVA
result$gsva_score_agreement
result$robustness_r2            # pathway-specific adjustment, KRAS-free phenotype and
                                # exclusion analyses (see below)
result$robustness_partial_cor   # baseline KRAS score vs phenotype (partial correlations)
result$ssgsea_results           # unnormalised ssGSEA instead of GSVA
result$ssgsea_contrasts
result$ssgsea_coupling_null
result$ssgsea_partial_cor
```

The exclusion analyses in `robustness_r2` depend on the predictors:

| Model | Exclusion analyses |
|---|---|
| `run_ptpm()`, `run_ptpm_egfr()`, `run_ptpm_weighted_score()` | KRAS_SIGNALING_UP genes excluded from the predictors |
| `run_ptpm_pathways()` | predictor pathways sharing more than 20% of genes with the outcome sets excluded (`overlap_threshold`) |
| `run_ptpm_hybrid()`, `run_ptpm_hybrid_interactions()` | both; interactions involving an excluded pathway are also removed |

Model-specific elements:

```r
results$egfr_axis$predictor_pool                    # EGFR-axis genes used as predictors
results$pathways$predictor_pathways                 # the 47 predictor pathways
results$pathways$pathway_overlap                    # gene overlap of each predictor pathway with the outcome sets
results$weighted_score$outcome_weights_global       # whole-cohort PC1 weights (descriptive only)
results$weighted_score$coupling_score               # coupling covariate ("weighted" or "mean")
results$hybrid$predictor_pathways                   # pathways always included
results$hybrid$predictor_gene_pool                  # EGFR-axis gene pool
results$hybrid_interaction$predictor_pathways       # pathways and interaction terms always included
results$hybrid_interaction$pathway_overlap
```

## 7. Inspect predictions

Out-of-fold predictions are stored per regime and per outer fold in
`result$fold_results`. Each element contains the fold index, the predictions
(one column per K) and the observed outcome.

In the coupling-adjusted regimes, the observed outcome is the training-fold
residual. In `run_ptpm_weighted_score()` it is the fold-specific PC1 score:
weights are estimated on each training fold, so outcomes of different folds
are on standardised but not identical scales.

```r
result <- results$egfr_axis
regime <- "fully_controlled"   # or "standard", "coupling_adjusted", "fold_internal"
fr <- result$fold_results[[regime]]
n  <- length(result$y)
preds <- do.call(rbind, lapply(fr, function(z) {
  test_idx <- setdiff(seq_len(n), result$folds[[z$fold]])
  data.frame(
    model     = names(result$y)[test_idx],
    repeat_id = as.integer(sub(".*_Rep", "", names(result$folds)[z$fold])),
    observed  = z$obs,
    setNames(as.data.frame(z$pred), paste0("pred_K", result$top_k_values))
  )
}))
head(preds)
```

## Notes

- **Runtime:** reduce `repeats` first for a faster check. Each robustness and
  sensitivity block can be switched off (`gsva_sensitivity`, `ssgsea_sensitivity`,
  `robustness`) or limited to the first repeats (`gsva_sensitivity_repeats`,
  `ssgsea_repeats`, `robustness_repeats`).
- **Pairing permutation null:** the full null of the NT/CET pairing
  (`n_perm > 0`) is optional and computationally heavy. It is off by default.
- **Interaction pathways:** in `run_ptpm_hybrid_interactions()` the pathways used
  for interactions (`interaction_pathways`) are treated as fixed a priori. If
  they were chosen using the outcome on the same samples, the resulting
  estimates are optimistic.
- **Reproducibility:** results are reproducible for a given `seed`, number of
  repeats and package versions (R, GSVA, glmnet). Report `sessionInfo()` together
  with the results.
